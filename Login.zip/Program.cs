﻿using System;

namespace Login
{
    class Program
    {
        public class CodifingThings
        {
            public static string PassHasher(string Pass, string Salt)
            {
                using (var codifier = SHA256.Create())
                {
                    byte[] codifiedBytes = codifier.ComputeHash(Encoding.UTF8.GetBytes(Pass + Salt));
                    StringBuilder construyeStrings = new StringBuilder();
                    foreach (var bytes in codifiedBytes)
                    {
                        construyeStrings.Append(bytes.ToString("X2"));
                    }

                    Pass = construyeStrings.ToString();
                    return Pass;
                }
            }

            public static string FullPassHasher(string Pass, out string Salt)
            {
                Salt = Guid.NewGuid().ToString();
                return PassHasher(Pass, Salt);
            }

        }
class LoginUsuario
        {
            public string Usuario { get; set; }
            public string Password { get; set; }
        }


        [HttpPost]
        [AllowAnonymous]
        public async Task<IHttpActionResult> LoginAsync(LoginUsuario Login)
        {
            if (Login == null)
                return BadRequest("Usuario y Contraseña requeridos.");

            var _userInfo = await AutenticarUsuarioAsync(Login);
            if (_userInfo != null)
            {
                return Ok(new { UserInfo = _userInfo, token = GenerarTokenJWT(_userInfo) });
            }
            else
            {
                return Unauthorized();
            }
        }

        // COMPROBAMOS SI EL USUARIO EXISTE EN LA BASE DE DATOS 
        private async Task<InformacionUsuario> AutenticarUsuarioAsync(LoginUsuario Login)
        {
            // AQUÍ LA LÓGICA DE AUTENTICACIÓN //

            var u = Users.Where(x => x.userName.Equals(Login.Usuario, StringComparison.OrdinalIgnoreCase)).FirstOrDefault();

            if (u != null)
            {
                bool Iscorrect = (u.Password == CodifingThings.PassHasher(Login.Password, u.Salt));
                if (Iscorrect)
                {
                    // El usuario existe en la Base de Datos.
                    // Retornamos un objeto con toda
                    // la información del usuario necesaria para el Token.
                    if (u.Estado == 1 || u.Estado == 2)
                        return u;
                }
            }

            // Si el usuario NO existe en la Base de Datos.
            // Retornamos NULL.
            return null;
        }
    }
}
